import java.util.Scanner;

public class Blackjack {

    public static void main(String[] args) {
        Scanner src = new Scanner(System.in);
        Baraja baraja = new Baraja();

        Jugador jugador = new Jugador("Jugador");
        Jugador dealer  = new Jugador("Dealer (IA)");

        double dinero   = 100;
        int ganadas     = 0;
        int perdidas    = 0;
        boolean salir   = false;

        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║     Bienvenido/a a Blackjack Java    ║");
        System.out.println("╚══════════════════════════════════════╝");

        while (!salir) {

            // ── RESET ──────────────────────────────────────────────
            jugador.resetearMano();
            dealer.resetearMano();

            // ── APUESTA ────────────────────────────────────────────
            int apuesta = 0;
            while (true) {
                System.out.printf("%nDinero disponible: %.1f€. Introduce tu apuesta: ", dinero);
                apuesta = src.nextInt();
                if (apuesta <= 0) {
                    System.out.println("La apuesta debe ser mayor que 0.");
                } else if (apuesta > dinero) {
                    System.out.println("No puedes apostar más dinero del que tienes.");
                } else {
                    break;
                }
            }
            dinero -= apuesta;

            // ── REPARTO INICIAL ────────────────────────────────────
            jugador.pedirCarta(baraja.repartirCarta());
            jugador.pedirCarta(baraja.repartirCarta());
            dealer.pedirCarta(baraja.repartirCarta());
            dealer.pedirCarta(baraja.repartirCarta());

            System.out.println();
            dealer.mostrarPrimeraCarta();   // Solo muestra 1 carta del dealer
            jugador.mostrarMano();

            // ── TURNO DEL JUGADOR ──────────────────────────────────
            while (!jugador.estaPasado() && !jugador.tieneBlackjack()) {
                System.out.print("¿Quieres pedir carta? (s/n): ");
                String respuesta = src.next().trim().toLowerCase();

                if (respuesta.equals("s")) {
                    jugador.pedirCarta(baraja.repartirCarta());
                    System.out.println();
                    dealer.mostrarPrimeraCarta();
                    jugador.mostrarMano();
                } else {
                    jugador.plantarse();
                    break;
                }
            }

            // ── TURNO DEL DEALER (IA) ──────────────────────────────
            // La IA aplica la regla estándar: pide carta si tiene menos de 17
            // Se añade una pequeña probabilidad de riesgo para más realismo
            System.out.println("\n── Turno del Dealer ──");
            dealer.mostrarMano();

            while (!jugador.estaPasado() && dealer.getPuntuacion() < 17) {
                System.out.println("El dealer pide carta...");
                dealer.pedirCarta(baraja.repartirCarta());
                dealer.mostrarMano();
            }

            // ── EVALUACIÓN DEL RESULTADO ───────────────────────────
            System.out.println("\n══════════ RESULTADO ══════════");
            jugador.mostrarMano();
            dealer.mostrarMano();

            int pJ = jugador.getPuntuacion();
            int pD = dealer.getPuntuacion();

            if (jugador.tieneBlackjack() && !dealer.tieneBlackjack()) {
                // Blackjack natural del jugador (paga 2.5x)
                System.out.println("¡BLACKJACK! ¡Multiplicaste tu apuesta x2.5!");
                dinero += apuesta * 2.5;
                ganadas++;

            } else if (dealer.tieneBlackjack() && !jugador.tieneBlackjack()) {
                // Blackjack del dealer
                System.out.println("El dealer tiene Blackjack. ¡Perdiste!");
                perdidas++;

            } else if (jugador.tieneBlackjack() && dealer.tieneBlackjack()) {
                // Ambos tienen Blackjack → empate
                System.out.println("Ambos tienen Blackjack. Empate. Recuperas tu apuesta.");
                dinero += apuesta;

            } else if (pJ > 21) {
                // Jugador se pasó
                System.out.println("Te pasaste de 21. ¡Perdiste!");
                perdidas++;

            } else if (pD > 21) {
                // Dealer se pasó
                System.out.println("¡El dealer se pasó! ¡Ganaste!");
                dinero += apuesta * 2;
                ganadas++;

            } else if (pJ > pD) {
                // Jugador gana
                System.out.println("¡Ganaste! Duplicas tu apuesta.");
                dinero += apuesta * 2;
                ganadas++;

            } else if (pJ < pD) {
                // Dealer gana
                System.out.println("El dealer tiene más puntos. ¡Perdiste!");
                perdidas++;

            } else {
                // Empate
                System.out.println("Empate. Recuperas tu apuesta.");
                dinero += apuesta;
            }

            // ── ESTADÍSTICAS ───────────────────────────────────────
            System.out.println("───────────────────────────────");
            System.out.printf("Dinero actual:     %.1f€%n", dinero);
            System.out.println("Partidas ganadas:  " + ganadas);
            System.out.println("Partidas perdidas: " + perdidas);

            // ── FIN DE DINERO ──────────────────────────────────────
            if (dinero <= 0) {
                System.out.println("\nHas perdido todo tu dinero. ¡Fin del juego!");
                break;
            }

            // ── CONTINUAR ──────────────────────────────────────────
            System.out.print("\n¿Quieres salir? (s/n): ");
            String resp = src.next().trim().toLowerCase();
            if (resp.equals("s")) salir = true;
        }

        System.out.println("\n¡Gracias por jugar! Hasta la próxima.");
        src.close();
    }
}

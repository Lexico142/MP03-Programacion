public class Carta {

    // Atributos
    private int valor;   // Valor numérico (1-13, donde 1=As, 11=J, 12=Q, 13=K)
    private String palo; // Palo de la carta (Corazones, Picas, Tréboles, Diamantes)

    // Constructor
    public Carta(int valor, String palo) {
        this.valor = valor;
        this.palo = palo;
    }

    // Devuelve el valor numérico real de la carta para el juego
    // As = 11 por defecto (se ajustará en Jugador si es necesario)
    // J, Q, K = 10
    // Resto = su valor numérico
    public int getValorJuego() {
        if (valor == 1) return 11;       // As vale 11 por defecto
        if (valor >= 11) return 10;      // J, Q, K valen 10
        return valor;
    }

    // Indica si la carta es un As (para la lógica de ajuste)
    public boolean esAs() {
        return valor == 1;
    }

    // Representación visual del valor de la carta
    public String getNombreValor() {
        return switch (valor) {
            case 1  -> "A";
            case 11 -> "J";
            case 12 -> "Q";
            case 13 -> "K";
            default -> String.valueOf(valor);
        };
    }

    // Getters
    public int getValor() { return valor; }
    public String getPalo() { return palo; }

    @Override
    public String toString() {
        return getNombreValor() + " de " + palo;
    }
}

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baraja {

    private List<Carta> cartas;
    private static final String[] PALOS = {"Corazones", "Picas", "Tréboles", "Diamantes"};

    // Constructor: genera una baraja completa de 52 cartas y la baraja
    public Baraja() {
        cartas = new ArrayList<>();
        for (String palo : PALOS) {
            for (int valor = 1; valor <= 13; valor++) {
                cartas.add(new Carta(valor, palo));
            }
        }
        Collections.shuffle(cartas);
    }

    // Reparte la carta del tope de la baraja
    public Carta repartirCarta() {
        if (cartas.isEmpty()) {
            // Si se acaban las cartas, regeneramos la baraja
            System.out.println("[Baraja nueva barajada]");
            for (String palo : PALOS) {
                for (int valor = 1; valor <= 13; valor++) {
                    cartas.add(new Carta(valor, palo));
                }
            }
            Collections.shuffle(cartas);
        }
        return cartas.remove(cartas.size() - 1);
    }
}

import java.util.ArrayList;
import java.util.List;

public class Jugador {

    // Atributos
    private String nombre;
    private List<Carta> mano;
    private boolean plantado;

    // Constructor
    public Jugador(String nombre) {
        this.nombre = nombre;
        this.mano = new ArrayList<>();
        this.plantado = false;
    }

    // Añade una carta a la mano del jugador
    public void pedirCarta(Carta carta) {
        mano.add(carta);
    }

    // El jugador se planta (deja de pedir cartas)
    public void plantarse() {
        this.plantado = true;
    }

    // Calcula la puntuación total de la mano, ajustando los Ases si es necesario
    public int getPuntuacion() {
        int total = 0;
        int ases = 0;

        for (Carta carta : mano) {
            total += carta.getValorJuego();
            if (carta.esAs()) ases++;
        }

        // Si nos pasamos de 21, convertimos Ases de 11 → 1 (restamos 10)
        while (total > 21 && ases > 0) {
            total -= 10;
            ases--;
        }

        return total;
    }

    // Devuelve true si el jugador se ha pasado de 21
    public boolean estaPasado() {
        return getPuntuacion() > 21;
    }

    // Devuelve true si el jugador tiene Blackjack natural (21 con 2 cartas)
    public boolean tieneBlackjack() {
        return mano.size() == 2 && getPuntuacion() == 21;
    }

    // Resetea la mano para una nueva partida
    public void resetearMano() {
        mano.clear();
        plantado = false;
    }

    // Muestra las cartas de la mano del jugador
    public void mostrarMano() {
        System.out.print(nombre + ": ");
        for (int i = 0; i < mano.size(); i++) {
            System.out.print(mano.get(i));
            if (i < mano.size() - 1) System.out.print(", ");
        }
        System.out.println(" [" + getPuntuacion() + " puntos]");
    }

    // Muestra solo la primera carta (para el dealer al inicio de la ronda)
    public void mostrarPrimeraCarta() {
        System.out.println(nombre + ": " + mano.get(0) + ", [carta oculta]");
    }

    // Getters
    public String getNombre() { return nombre; }
    public List<Carta> getMano() { return mano; }
    public boolean isPlantado() { return plantado; }
}
